// app/(tabs)/_layout.tsx
import { Tabs } from 'expo-router';

export default function TabLayout() {
  return (
    <Tabs>
      <Tabs.Screen name="market" options={{ title: "Market" }} />
      <Tabs.Screen name="upgrades" options={{ title: "Upgrades" }} />
      <Tabs.Screen name="price-history" options={{ title: "History" }} />
      <Tabs.Screen name="settings" options={{ title: "Settings" }} />
    </Tabs>
  );
}
