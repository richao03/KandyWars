// app/CandyMarket.tsx
import React, { useState } from 'react';
import { Button, FlatList, StyleSheet, Text, View } from 'react-native';

type Candy = {
  name: string;
  baseMin: number;
  baseMax: number;
  cost: number;
  quantityOwned: number;
  averagePrice: number | null;
};

import { getRandomPrice } from "../../utils/priceUtils";

const initialCandies: Candy[] = [
  { name: 'Snickers', baseMin: 1.5, baseMax: 3, cost: 0, quantityOwned: 0, averagePrice: null },
  { name: 'M&Ms', baseMin: 1.0, baseMax: 2.5, cost: 0, quantityOwned: 0, averagePrice: null },
  { name: 'Skittles', baseMin: 0.75, baseMax: 2.25, cost: 0, quantityOwned: 0, averagePrice: null },
  { name: 'Warheads', baseMin: 0.25, baseMax: 1.0, cost: 0, quantityOwned: 0, averagePrice: null },
  { name: 'Sour Patch Kids', baseMin: 1.0, baseMax: 2.75, cost: 0, quantityOwned: 0, averagePrice: null },
  { name: 'Bubble Gum', baseMin: 0.1, baseMax: 0.5, cost: 0, quantityOwned: 0, averagePrice: null },
].map(c => ({
  ...c,
  cost: getRandomPrice(c.baseMin, c.baseMax),
}));

export default function CandyMarket() {
  const [candies, setCandies] = useState(initialCandies);

  const handleBuy = (index: number) => {
    setCandies((prev) =>
      prev.map((candy, i) =>
        i === index
          ? {
            ...candy,
            quantityOwned: candy.quantityOwned + 1,
            averagePrice: candy.averagePrice === null
              ? candy.cost
              : (candy.averagePrice * candy.quantityOwned + candy.cost) / (candy.quantityOwned + 1),
          }
          : candy
      )
    );
  };

  const handleNextDay = () => {
    setCandies((prev) =>
      prev.map((candy) => ({
        ...candy,
        cost: getRandomPrice(candy.baseMin, candy.baseMax),
      }))
    );
  };


  return (
    <>
      <FlatList
        data={candies}
        keyExtractor={(item) => item.name}
        contentContainerStyle={styles.list}
        renderItem={({ item, index }) => (
          <View style={styles.item}>
            <Text style={styles.name}>{item.name}</Text>
            <Text>Price: ${item.cost.toFixed(2)}</Text>
            <Text>Owned: {item.quantityOwned}</Text>
            <Text>
              Avg Price: {item.averagePrice !== null ? `$${item.averagePrice.toFixed(2)}` : '—'}
            </Text>
            <Button title="BUY" onPress={() => handleBuy(index)} />
          </View>
        )}
      />
      <View style={styles.buttonContainer}>
        <Button title="Next Day" onPress={handleNextDay} />
      </View>
    </>

  );
}

const styles = StyleSheet.create({
  list: {
    padding: 20,
  },
  item: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: '#eee',
    borderRadius: 10,
  },
  name: {
    fontWeight: 'bold',
    fontSize: 18,
  },
  buttonContainer: {
    marginTop: 20,
    paddingHorizontal: 20,
  }
});
