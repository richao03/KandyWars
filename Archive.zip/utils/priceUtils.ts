// utils/priceUtils.ts
export const getRandomPrice = (min: number, max: number): number => {
  const price = Math.random() * (max - min) + min;
  return parseFloat(price.toFixed(2));
};
